Solve the tasks in **a,b,c,d**  
There is an example in the file ```example.mjs``` to show how a comple task could look.  
Test.mjs contains our basic testing framework, this is the framwork you are to use when writing tests.

All tasks should be able to run using ```node nameOFTask.mjs```  
You should run the example to see how it looks.  


